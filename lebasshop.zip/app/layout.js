'use client';

import './globals.css';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Footer from '../components/footer';
import { useCartStore } from '../store/usecartstore'; // مسیر دقیق به استور خودت را بزن

export default function RootLayout({ children }) {
  const pathname = usePathname();
  const totalItems = useCartStore(state => state.cartItems.length); // تعداد کل محصولات در سبد

  const menuItems = [
    { name: 'خانه', href: '/', icon: '🏠' },
    { name: 'فروشگاه', href: '/shop-site', icon: '🛍️' },
    { name: 'محصولات', href: '/products', icon: '👕' },
    { name: 'سبد خرید', href: '/cart', icon: '🛒' },
    { name: 'درباره ما', href: '/about', icon: 'ℹ️' },
  ];

  return (
    <html lang="fa" dir="rtl" className="bg-white">
      <head />
      <body className="bg-white min-h-screen text-black font-sans flex flex-col">

        {/* کل صفحه سفید و ارتفاع کامل */}
        <div className="flex flex-col min-h-screen bg-white">

          {/* هدر قرمز با گوشه گرد پایین */}
          <header className="bg-red-600 rounded-b-xl shadow border-b border-red-700 w-full">
            <nav className="max-w-6xl mx-auto flex justify-between items-center px-6 py-3">
              <h1 className="text-2xl font-bold text-white">فروشگاه لباس</h1>
              <ul className="flex space-x-reverse space-x-6">
                {menuItems.map((item) => (
                  <li key={item.name} className="relative">
                    <Link
                      href={item.href}
                      className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors duration-300 ${
                        pathname === item.href
                          ? 'bg-white text-red-600 shadow-md'
                          : 'text-white hover:bg-red-500'
                      }`}
                    >
                      <span className="text-xl relative">
                        {item.icon}
                        {item.name === 'سبد خرید' && totalItems > 0 && (
                          <span className="absolute -top-2 -right-3 bg-yellow-400 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                            {totalItems}
                          </span>
                        )}
                      </span>
                      <span>{item.name}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          </header>

          {/* محتوای اصلی */}
          <main className="flex-grow bg-white max-w-6xl mx-auto p-6 w-full">
            {children}
          </main>

          {/* فوتر */}
          <Footer />
        </div>

      </body>
    </html>
  );
}
